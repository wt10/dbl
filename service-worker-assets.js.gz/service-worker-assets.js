﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-EqVmRe2qZ\/8oe8NRmXWK0PCJZbrTw9ChGx3RFsePaGY=",
      "url": "Assests\/Images\/wainfoLogo.jpg"
    },
    {
      "hash": "sha256-8aM9R9K90X6h+KPDW4OzrEh071mAs7dvAQxjBxAZQAc=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-rldnE7wZYJj3Q43t5v8fg1ojKRwyt0Wtfm+224CacZs=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-xMZ0SaSBYZSHVjFdZTAT\/IjRExRIxSriWcJLcA9nkj0=",
      "url": "css\/bootstrap\/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-jA4J4h\/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh\/chSkSvQpc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-aF5g\/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU\/ss=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-p\/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA\/tb0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-IpHFcQvs03lh6W54zoeJRG1jW+VnGmwymzxLoXtKX7Y=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-t0V08Yl7phjrE4p2wKSzXtNpSCd6Ax92fRMsvSqWfoY=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fJ+e\/wwsEyddbTNMYL8Ev2eNJqxCxyfm3IcQTIKRXjY=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yzFf+O\/mlH+Q9klUSqXP2kxGKOUFLPxaww8da8fKhGU=",
      "url": "sample-data\/weather.json"
    },
    {
      "hash": "sha256-eD1xx9KVSZ9Xc134LY9VKnKHGzf6M2yPGh+GxiRBQw0=",
      "url": "_framework\/dotnet.timezones.blat"
    },
    {
      "hash": "sha256-sM00FtqUHIlrUdb02MY\/qfdHC8Wj3ZQzQbgAHOGI\/QM=",
      "url": "_framework\/dotnet.wasm"
    },
    {
      "hash": "sha256-m7NyeXyxM+CL04jr9ui1Z6pVfMWwhHusuz5qNZWpAwA=",
      "url": "_framework\/icudt.dat"
    },
    {
      "hash": "sha256-91bygK5voY9lG5wxP0\/uj7uH5xljF9u7iWnSldT1Z\/g=",
      "url": "_framework\/icudt_CJK.dat"
    },
    {
      "hash": "sha256-DPfeOLph83b2rdx40cKxIBcfVZ8abTWAFq+RBQMxGw0=",
      "url": "_framework\/icudt_EFIGS.dat"
    },
    {
      "hash": "sha256-oM7Z6aN9jHmCYqDMCBwFgFAYAGgsH1jLC\/Z6DYeVmmk=",
      "url": "_framework\/icudt_no_CJK.dat"
    },
    {
      "hash": "sha256-bHu90HVES4SKyUFhMpzoBXzOukU4TR6+P2ZsSqV5b6Q=",
      "url": "_framework\/dotnet.5.0.0-rc.2.20475.5.js"
    },
    {
      "hash": "sha256-8e8LGVUXMwavrcEpPQuXen1cW28ozWuOO3RgAggP\/80=",
      "url": "DBL.Client.styles.css"
    },
    {
      "hash": "sha256-wEwhASbSl7R\/aFICWusQUu1ZHqy+VAMvC5CjhmTw2FY=",
      "url": "_content\/Blazored.Toast\/blazored-toast.css"
    },
    {
      "hash": "sha256-zzSJLCGj8lFnpM7CuhKbhIVfDTz5chJhB609EntEno4=",
      "url": "_content\/Blazored.Toast\/blazored-toast.min.css"
    },
    {
      "hash": "sha256-+\/IJo9wLK9sTvL8ee9W9w8S1Gkj8rsf\/6yob0uUFAaM=",
      "url": "_framework\/Blazored.LocalStorage.dll"
    },
    {
      "hash": "sha256-MDjySzmkI2jhu1aPQfR0Zesy4BVTa8p67jS+Nk5ibOs=",
      "url": "_framework\/Blazored.Toast.dll"
    },
    {
      "hash": "sha256-sUuy9mmlUFQ5lJhk352To9PxTrDGsOUTwS5TkaXJE5I=",
      "url": "_framework\/Microsoft.AspNetCore.Authorization.dll"
    },
    {
      "hash": "sha256-8N\/LiUTyuHwq9Nh9PF007wA8Azi0D\/d8rdP3K0SroKw=",
      "url": "_framework\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-nNuchfFuIuEhvf\/8W2DM6\/GfkVO4hFmlksfC4vZI88U=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Authorization.dll"
    },
    {
      "hash": "sha256-xPXOh572lSnQYEey+CLOor7oSShB37KCZC9XTvnJijk=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Forms.dll"
    },
    {
      "hash": "sha256-gwT6GNS6f+zVnEQQIQRt1w\/kjgcQMJ2A3\/pGCBJs7K8=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-2lcJTTI48BoYHAlmuMB0R1o1EF24XKCM4nOLXHp49X4=",
      "url": "_framework\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-wjrEumrk9z19zqv1jbfKQvCBUoxrd3olFV0v+siRg+s=",
      "url": "_framework\/Microsoft.AspNetCore.Http.Abstractions.dll"
    },
    {
      "hash": "sha256-+BnmchT3cKhIWi+FM1xLhXSHNtNDxUX1EK6+or8\/Hz0=",
      "url": "_framework\/Microsoft.AspNetCore.Http.Features.dll"
    },
    {
      "hash": "sha256-zAg8ZcCu3BOV5Jl1lUYOBFtaGuaunUfQIRr7sjV+br4=",
      "url": "_framework\/Microsoft.AspNetCore.Metadata.dll"
    },
    {
      "hash": "sha256-vMs3vsCtR7HXRQSCAqjye1H2dxKUaiXBHvh5VffqPdY=",
      "url": "_framework\/Microsoft.AspNetCore.ResponseCompression.dll"
    },
    {
      "hash": "sha256-9OCW0QFjxOrvRWXpJ7m+TVT7mTfv5rLQt41a7XlyqZ0=",
      "url": "_framework\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-hlqoWwerHArflpdgJrSwMtY1dsH8SJdt2bqet8WDQ8s=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-frHP5hTUWKPr2ZFciNktCaOcSiSVX7HpcRzClHDGjWQ=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-GHJWhSDti4MKEKyBqXRCYq2KrSnE4C6TVWbOlxyd2p0=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-EmXWhU\/sAhnWy4Jr0jCxtctWYx6jph+DBEi+ItQ6\/G4=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-fP0Z0I0+SSnMqUByWM0JeO1zatvDlMBPufAi2K+EN6M=",
      "url": "_framework\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-FxBI9hIAwmzIXcTR6k3Pgegldiv\/FkqtHwwzLNv5\/CU=",
      "url": "_framework\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-xXXXke0fSBa6Oq7FAlIgoAjsqoQ7MTzkfK3vdBA5BbQ=",
      "url": "_framework\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-2GiZlOh9+nv\/JwIlS5l1XDE6baMvVMSQg2WuvA90Xbc=",
      "url": "_framework\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-uAzJwLsEqJeBTHqXwttCYWO7Oh+jtUjTfnnWhrHmRGM=",
      "url": "_framework\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-lKafcju84crv4afu7rzVNX9CUQClrW6hMrRXLDKAkJI=",
      "url": "_framework\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-Wvp5b2xB1gZg9yya2UqQycv2STns92xStLKpmRv5Aww=",
      "url": "_framework\/Microsoft.Net.Http.Headers.dll"
    },
    {
      "hash": "sha256-+ADP8S4Rwb9fxn+kdR4cWYmvPtc92ZGPMIIGN5AiBsQ=",
      "url": "_framework\/System.IO.Pipelines.dll"
    },
    {
      "hash": "sha256-dXamFbzJjx59CN7HPEmlxil8HtgZvcIKl9nT2r1JavI=",
      "url": "_framework\/DBL.Shared.dll"
    },
    {
      "hash": "sha256-SFM7EhGBouzp4THem7gdkzi4sjwQP\/xkJaLBW0YQIwM=",
      "url": "_framework\/DBL.Client.dll"
    },
    {
      "hash": "sha256-pQSkApcEINghivQg10Qx7dbp3BVuV0KiNhK5rSnfoCk=",
      "url": "_framework\/System.Collections.Concurrent.dll"
    },
    {
      "hash": "sha256-IRt+2CEqWF\/eR1lUEQ3Sd5DGQoZcUDAjO7wggeBsh9Q=",
      "url": "_framework\/System.Collections.Immutable.dll"
    },
    {
      "hash": "sha256-MGpve005\/jX1AQKRVhxSB8eYyRhhRLozlfkcalpGyiw=",
      "url": "_framework\/System.Collections.NonGeneric.dll"
    },
    {
      "hash": "sha256-aasMOf4tE4+0fUyJhPJfJLd3VPZZ6eqO0GO2LjYat6A=",
      "url": "_framework\/System.Collections.Specialized.dll"
    },
    {
      "hash": "sha256-9+bTi4rQnPHQYjO4MBM8JXhdXJB1k2SsRwibQQzJoz8=",
      "url": "_framework\/System.Collections.dll"
    },
    {
      "hash": "sha256-sMUb8+We\/L+oQM2r\/0NmszaHl7oGtnup9KuGeUsAigo=",
      "url": "_framework\/System.ComponentModel.Annotations.dll"
    },
    {
      "hash": "sha256-EaX0oXKH\/ZmpnKH0qDtwYKEWdaITponT0ueUHf1DDRQ=",
      "url": "_framework\/System.ComponentModel.Primitives.dll"
    },
    {
      "hash": "sha256-QQ8t1AFoAovkrL7MJigZ1roiqV0lpLuzUQOn2VcmiEM=",
      "url": "_framework\/System.ComponentModel.TypeConverter.dll"
    },
    {
      "hash": "sha256-is\/4ynRk3MBK83XzrbTe60AWXnEfnXF+eehawfKoTbE=",
      "url": "_framework\/System.ComponentModel.dll"
    },
    {
      "hash": "sha256-lnyE24Gq8+P3AuUKUqDjeGUhVwaa38K1kVJ\/oPeA9hs=",
      "url": "_framework\/System.Console.dll"
    },
    {
      "hash": "sha256-x3zik7F0hQb7vgJR22SMXnHoLx3CPhsimwYjglnv\/DA=",
      "url": "_framework\/System.IO.Compression.Brotli.dll"
    },
    {
      "hash": "sha256-Rc9Z1miLsuWIuT+OJdNEn4Z1LMYCEE2Al2v\/DZg03H8=",
      "url": "_framework\/System.IO.Compression.dll"
    },
    {
      "hash": "sha256-r\/jVtOxwGoprrIZKygkNWb4AE2HdraX1Fe2sMMbieSE=",
      "url": "_framework\/System.Linq.Expressions.dll"
    },
    {
      "hash": "sha256-P7\/WZmJmVx5NqjjB\/33i+qjanAFlWQ8YS6BQT9aiCcY=",
      "url": "_framework\/System.Linq.dll"
    },
    {
      "hash": "sha256-w1WUHRkkQkomMPddUnEf1gYm37rPmazRXfOixWIh1dA=",
      "url": "_framework\/System.Memory.dll"
    },
    {
      "hash": "sha256-Z2ifI44K+tqv+Le\/MKFmSl96JZCXs+6Qxv3OwmJFEms=",
      "url": "_framework\/System.Net.Http.Json.dll"
    },
    {
      "hash": "sha256-IkMiIS53HgUtrqntjzb0qT2cmFKdlp6sJIf1Shssm24=",
      "url": "_framework\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-J3Co9e3i0u\/xkXs7fKJTD0Xyetu21n3oNiUpuxA4X3I=",
      "url": "_framework\/System.Net.Primitives.dll"
    },
    {
      "hash": "sha256-q6zCMwRDMm22cwu121UF6HXTuIjYIDqWCDhjb1O1+x4=",
      "url": "_framework\/System.Net.WebSockets.dll"
    },
    {
      "hash": "sha256-DucsUrzclpnKmIP7zRXgWIvKe7+ObilxglRgJ8ayhE0=",
      "url": "_framework\/System.ObjectModel.dll"
    },
    {
      "hash": "sha256-4d1qMBxyYz2asygEPo01+Dx2Z5Ne4LpstWXyYRvhCz8=",
      "url": "_framework\/System.Private.Runtime.InteropServices.JavaScript.dll"
    },
    {
      "hash": "sha256-TGWdnKNEEXhlQq1LVVbPqwNuH4tcANTBRBmVWC1XZv0=",
      "url": "_framework\/System.Private.Uri.dll"
    },
    {
      "hash": "sha256-oF830GyTy9NWflKWUISOuQopROpgzlNpuizWMOjb7zA=",
      "url": "_framework\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-1mB2U9qwYoQ6CYGk7zD3acnEVoJpDWvScOHKYBS813w=",
      "url": "_framework\/System.Runtime.InteropServices.RuntimeInformation.dll"
    },
    {
      "hash": "sha256-XNhOHwsl2Y6drTw4OU0zhHS4UmnzNC9ObqFr+qdIXfk=",
      "url": "_framework\/System.Security.Claims.dll"
    },
    {
      "hash": "sha256-DDWzLR\/K6MVJqq2NXMJux8yuJXr8wW8Q7HZ5JDKbCRg=",
      "url": "_framework\/System.Security.Cryptography.X509Certificates.dll"
    },
    {
      "hash": "sha256-KpcEOJrLo0Q+JZlnwlv+ZlZgfxKdR6Cn8E4xGjwC4Wg=",
      "url": "_framework\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-4chiichKxAZ9aySLJinCyS0jMruWIEucCJfRbncRyEo=",
      "url": "_framework\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-mIRfzTNEEWWCQwyNFZBOoM6XkKE6JftibgzjOIHLmRE=",
      "url": "_framework\/System.Text.RegularExpressions.dll"
    },
    {
      "hash": "sha256-RT0ybWJHFWVnXesq3xrk3owwcgaUDZ8PTvZoBosv1yQ=",
      "url": "_framework\/System.Private.CoreLib.dll"
    },
    {
      "hash": "sha256-rYgWXHKy+iNNL0ApaYNqpj23UdI9Ah0IUzozzN9GFcM=",
      "url": "_framework\/blazor.boot.json"
    },
    {
      "hash": "sha256-Vep8x7q0bd8IwjgvLpIvzJUzZgnMYDGdAEU5ys8rTcA=",
      "url": "_framework\/blazor.webassembly.js"
    }
  ],
  "version": "EV2Oef21"
};
